import Layout from "@/components/layout";
import Button from "@/components/Button";
import Dropdown from "@/components/Dropdown";
import { useEffect, useState } from "react";
import Input from "@/components/Input";
import Avatar from "@/components/Avatar";
import Profile from "@/components/Profile";
import SideNavigation from "@/components/SideNavigation";
import TopNavigation from "../../components/TopNavigation";
import Table from "@/components/Table";
import ChartArea from "@/components/ChartArea";
import ChartArea2 from "@/components/ChartArea2";
import { BarChart } from "../../components/BarChart";
import { useRouter } from "next/router";
import { useSession } from "next-auth/react";

const menu: any = [
  {
    title: "Dashboard",
    active: false,
  },
  {
    title: "My Wallet",
    active: false,
  },
  {
    title: "Transaction",
    active: false,
  },
  {
    title: "Analytics",
    active: false,
  },
  {
    title: "Reports",
    active: false,
  },
  {
    title: "Message",
    active: false,
  },
  {
    title: "Settings",
    active: false,
  },
];

export default function IndexPage() {
  const [dropdown, setDropdown] = useState([
    {
      key: 1,
      value: "Weekly",
    },
    {
      key: 2,
      value: "Monthly",
    },
    {
      key: 3,
      value: "Annually",
    },
  ]);

  const [profile, setProfile] = useState({
    name: "Adam Levine",
    designation: "Digital Designer",
    image:
      "https://images.unsplash.com/photo-1491528323818-fdd1faba62cc?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
  });

  const [navBar, setNavBar] = useState();
  const setTheme: any =
    typeof window != "undefined" && localStorage.getItem("dark-theme");
  const [darkTheme, setDarkTheme]: any = useState(JSON.parse(setTheme));

  useEffect(() => {
    setNavBar(menu);
  }, []);

  const handleActive = (index: number) => {
    const newArr: any = [...menu];
    newArr[index].active = true;
    setNavBar(newArr);
  };

  const getFormattedNumber = (number: number) => {
    return new Intl.NumberFormat("en-IN", {
      maximumSignificantDigits: 2,
    }).format(number);
  };

  const data = [
    {
      date: "01-20-2023",
      day: "THU",
      subscriber: 11652890,
      video_views: 1234764,
      growth: 44,
      estimated_earnings: "$0-$5.2K",
      status: "great",
    },
    {
      date: "01-27-2023",
      day: "TUE",
      subscriber: 10252890,
      video_views: 1234764,
      growth: 44,
      estimated_earnings: "$0-$5.2K",
      status: "good",
    },
    {
      date: "02-15-2023",
      day: "MON",
      subscriber: 9892233,
      video_views: 1234764,
      growth: 44,
      estimated_earnings: "$0-$5.2K",
      status: "great",
    },
    {
      date: "02-27-2023",
      day: "FRI",
      subscriber: 8622890,
      video_views: 1234764,
      growth: -24,
      estimated_earnings: "$0-$5.2K",
      status: "bad",
    },
    {
      date: "02-15-2023",
      day: "MON",
      subscriber: 9892233,
      video_views: 1234764,
      growth: 44,
      estimated_earnings: "$0-$5.2K",
      status: "good",
    },
  ];

  const columns = [
    {
      Header: () => (
        <div
          style={{
            textAlign: "left",
          }}
        >
          Date
        </div>
      ),
      accessor: "date",
      Cell: ({ row }: any) => {
        return (
          <div className="px-4 py-6">
            {row.values.date}
            <span className="ml-2 text-sm text-gray-400">
              {row.original.day}
            </span>{" "}
          </div>
        );
      },
    },
    {
      Header: "Subscribers",
      accessor: "subscriber",
      Cell: ({ row }: any) => {
        return (
          <div className="px-4 py-4 text-center">
            {getFormattedNumber(row.values.subscriber)}
          </div>
        );
      },
    },
    {
      Header: "Video Views",
      accessor: "video_views",
      Cell: ({ row }: any) => {
        return (
          <div className="px-4 py-4 text-center">
            {getFormattedNumber(row.values.video_views)}
          </div>
        );
      },
    },
    {
      Header: "Growth",
      accessor: "growth",
      Cell: ({ row }: any) => {
        return (
          <div
            className={`text-green px-4 py-4 text-center font-bold text-green-500 ${
              row.values.growth < 0 ? "text-red-500" : "text-green-500"
            } `}
          >
            {row.values.growth > 0 && "+"}
            {row.values.growth}%
          </div>
        );
      },
    },
    {
      Header: "Estimated Earnings",
      accessor: "estimated_earnings",
      Cell: ({ row }: any) => {
        return (
          <div className="px-4 py-4 text-center">
            {row.values.estimated_earnings}
          </div>
        );
      },
    },
    {
      Header: "Status",
      accessor: "status",
      Cell: ({ row }: any) => {
        if (row.values.status === "great") {
          return (
            <span className="mx-auto block w-28 rounded-2xl bg-green-100 p-2 text-center text-sm font-semibold uppercase text-green-500">
              {row.values.status}
            </span>
          );
        } else if (row.values.status === "good") {
          return (
            <span className="mx-auto block w-28 rounded-2xl bg-blue-100 p-2  text-center  text-sm font-semibold uppercase text-blue-500">
              {row.values.status}
            </span>
          );
        } else if (row.values.status === "bad") {
          return (
            <span className="mx-auto block w-28 rounded-2xl bg-red-100 p-2 text-center  text-sm font-semibold uppercase text-red-500">
              {row.values.status}
            </span>
          );
        }
        return null;
      },
    },
  ];

  const categories = ["Mon", "Tue", "Wed", "Thus", "Fri", "Sat", "Sun"];
  const chartData = [
    {
      type: "column",
      data: [100, 75, 80, 40, 80, 20, 55],
    },
    {
      type: "column",
      data: [75, 50, 50, 25, 80, 60, 45],
    },
  ];

  return (
    <Layout
    // darkTheme={darkTheme}
    // setDarkTheme={setDarkTheme}
    >
      <div className="ml-auto w-full p-4 sm:w-[calc(100%-256px)]">
        <main>
          <div>
            <TopNavigation
              setDarkTheme={setDarkTheme}
              darkTheme={darkTheme}
              profileData={profile}
            />
          </div>
          <div className="space-y-2">
            <h3 className="p-2 font-bold">Charts Type 1</h3>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-4">
              <ChartArea title="Followers" value="203" changeRate="+3.4%" />
              <ChartArea
                title="Followers"
                value="-2.345k"
                changeRate="-16.1%"
                darkTheme={darkTheme}
              />
              <ChartArea title="Followers" value="-1" changeRate="0.0%" />
              <ChartArea title="Followers" value="203" changeRate="+3.4%" />
            </div>
          </div>

          <div className="space-y-2">
            <h3 className="p-2 font-bold">Charts Type 2</h3>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-4">
              <ChartArea2
                title="Followers Gained (Weekly)"
                value="2846"
                date="01/20/23"
                changeRate="+3.4%"
                type="Followers"
              />
              <ChartArea2
                down
                title="Followers Gained (Weekly)"
                value="3731"
                date="01/20/23"
                changeRate="-8.4%"
                type="Followers"
              />
              <ChartArea2
                down
                title="Followers Gained (Weekly)"
                value="2846"
                date="01/20/23"
                changeRate="+3.4%"
                type="Tweets"
              />
              <ChartArea2
                down
                title="Followers Gained (Weekly)"
                value="2846"
                date="01/20/23"
                changeRate="+3.4%"
                type="Tweets"
              />
            </div>
          </div>
          {/* <div className="space-y-2">
            <h3 className="p-2 font-bold">Bar Chart</h3>
            <div className="grid grid-cols-1 gap-4 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-2">
              <BarChart
                title="Followers Gained (Weekly)"
                categories={categories}
                data={chartData}
              />
            </div>
          </div> */}
          {/* <div>
            <h3 className="p-2 font-bold">Buttons</h3>
            <Button variant="primary" title="Button" />
            <Button variant="warning" title="Button" />
            <Button variant="primary-border" title="Button" />
            <Button variant="white" title="Button" />
            <Button variant="default" title="Button" />
            <Button variant="default-border" title="Button" />
            <Button variant="link" title="Button" />
          </div>
          <div>
            <h3 className="p-2 font-bold">Dropdown</h3>
            <div>Selected option: {selected}</div>
            <Dropdown
              title="Dropdown"
              data={dropdown}
              handleSelected={handleSelected}
            />
          </div>

          <div>
            <h3 className="p-2 font-bold">Search Bar</h3>
            <Input
              placeholder="Search Data or some visualization"
              variant="search"
            />
          </div>

          <div>
            <h3 className="p-2 font-bold">Avatar</h3>
            <Avatar src={profile.image} />
          </div>

          <div>
            <h3 className="p-2 font-bold">Profile</h3>
            <Profile profileData={profile} />
          </div> */}

          <div className="mt-5 rounded-[12px] p-6 shadow-[0_0_14px_rgb(0,0,0,0.1)]">
            <h3 className="pb-7 pt-3 font-bold">Followers Gained (Weekly)</h3>
            <Table columns={columns} data={data} darkTheme={darkTheme} />
          </div>
        </main>
      </div>
      <div>
        <h3 className="p-2 font-bold">Side Navigation</h3>
        <SideNavigation mode="dark" menu={navBar} handleActive={handleActive} />
      </div>
    </Layout>
  );
}
