"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/examples/protected";
exports.ids = ["pages/api/examples/protected"];
exports.modules = {

/***/ "next-auth/react":
/*!**********************************!*\
  !*** external "next-auth/react" ***!
  \**********************************/
/***/ ((module) => {

module.exports = require("next-auth/react");

/***/ }),

/***/ "(api)/./src/pages/api/examples/protected.tsx":
/*!**********************************************!*\
  !*** ./src/pages/api/examples/protected.tsx ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ protectedHandler)\n/* harmony export */ });\n/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! next-auth/react */ \"next-auth/react\");\n/* harmony import */ var next_auth_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_auth_react__WEBPACK_IMPORTED_MODULE_0__);\n\nasync function protectedHandler(req, res) {\n    const session = await (0,next_auth_react__WEBPACK_IMPORTED_MODULE_0__.getSession)({\n        req\n    });\n    if (session) {\n        return res.send({\n            content: \"This is protected content. You can access this content because you are signed in.\"\n        });\n    }\n    res.send({\n        error: \"You must be sign in to view the protected content on this page.\"\n    });\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9zcmMvcGFnZXMvYXBpL2V4YW1wbGVzL3Byb3RlY3RlZC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQTZDO0FBRzlCLGVBQWVDLGlCQUM1QkMsR0FBbUIsRUFDbkJDLEdBQW9CLEVBQ3BCO0lBQ0EsTUFBTUMsVUFBVSxNQUFNSiwyREFBVUEsQ0FBQztRQUFFRTtJQUFJO0lBRXZDLElBQUlFLFNBQVM7UUFDWCxPQUFPRCxJQUFJRSxJQUFJLENBQUM7WUFDZEMsU0FDRTtRQUNKO0lBQ0YsQ0FBQztJQUVESCxJQUFJRSxJQUFJLENBQUM7UUFDUEUsT0FBTztJQUNUO0FBQ0YsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL25leHQtdGFpbHdpbmQtdHlwZXNjcmlwdC1zdGFydGVyLy4vc3JjL3BhZ2VzL2FwaS9leGFtcGxlcy9wcm90ZWN0ZWQudHN4P2VmZGEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgZ2V0U2Vzc2lvbiB9IGZyb20gXCJuZXh0LWF1dGgvcmVhY3RcIjtcclxuaW1wb3J0IHR5cGUgeyBOZXh0QXBpUmVxdWVzdCwgTmV4dEFwaVJlc3BvbnNlIH0gZnJvbSBcIm5leHRcIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uIHByb3RlY3RlZEhhbmRsZXIoXHJcbiAgcmVxOiBOZXh0QXBpUmVxdWVzdCxcclxuICByZXM6IE5leHRBcGlSZXNwb25zZVxyXG4pIHtcclxuICBjb25zdCBzZXNzaW9uID0gYXdhaXQgZ2V0U2Vzc2lvbih7IHJlcSB9KTtcclxuXHJcbiAgaWYgKHNlc3Npb24pIHtcclxuICAgIHJldHVybiByZXMuc2VuZCh7XHJcbiAgICAgIGNvbnRlbnQ6XHJcbiAgICAgICAgXCJUaGlzIGlzIHByb3RlY3RlZCBjb250ZW50LiBZb3UgY2FuIGFjY2VzcyB0aGlzIGNvbnRlbnQgYmVjYXVzZSB5b3UgYXJlIHNpZ25lZCBpbi5cIixcclxuICAgIH0pO1xyXG4gIH1cclxuXHJcbiAgcmVzLnNlbmQoe1xyXG4gICAgZXJyb3I6IFwiWW91IG11c3QgYmUgc2lnbiBpbiB0byB2aWV3IHRoZSBwcm90ZWN0ZWQgY29udGVudCBvbiB0aGlzIHBhZ2UuXCIsXHJcbiAgfSk7XHJcbn1cclxuIl0sIm5hbWVzIjpbImdldFNlc3Npb24iLCJwcm90ZWN0ZWRIYW5kbGVyIiwicmVxIiwicmVzIiwic2Vzc2lvbiIsInNlbmQiLCJjb250ZW50IiwiZXJyb3IiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./src/pages/api/examples/protected.tsx\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./src/pages/api/examples/protected.tsx"));
module.exports = __webpack_exports__;

})();