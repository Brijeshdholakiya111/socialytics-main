import { Dashboard } from "../menu/Dashboard";
import { Wallet } from "../menu/Wallet";
import { Transaction } from "../menu/Transaction";
import { Analytics } from "../menu/Analytics";
import { Reports } from "../menu/Reports";
import { Message } from "../menu/Message";
import { Settings } from "../menu/Settings";

type MenuType = {
  handleActive: (index: number) => void;
  menu: any;
  mode: string;
};
const SideNavigation = (props: MenuType) => {
  const handleActive = (title: number) => {
    props.handleActive(title);
  };
  console.log("====", props.menu);
  return (
    <aside className="fixed top-0 left-0 z-40 h-screen w-64 -translate-x-full transition-transform sm:translate-x-0">
      <div
        className={`h-full overflow-y-auto ${
          props?.mode === "light" ? "bg-white" : "bg-[#011B38]"
        }`}
      >
        <div className="bg-[#011B38]  p-8">
          <img src="/images/logo.png" />
        </div>
        <ul
          className={`space-y-2 ${
            props?.mode === "light" ? "bg-white" : "bg-[#011B38]"
          }`}
        >
          {props?.menu?.map((element: any, index: number) => (
            <li key={index}>
              <a
                href="#"
                onClick={(e) => handleActive(index)}
                className={`flex items-center py-4 pl-14 text-base text-[18px] font-normal ${
                  props?.mode === "light"
                    ? element.active && props.mode === "light"
                      ? "text-[#EC2A90]"
                      : "text-[#A9A9A9]"
                    : "text-white"
                } ${
                  props?.mode === "light"
                    ? "hover:bg-[#3080FE]"
                    : "hover:bg-[#3080FE]"
                } ${
                  element.active && props.mode === "dark" ? "bg-[#3080FE]" : ""
                } ${
                  element.active && props.mode === "light"
                    ? "text-[#EC2A90]"
                    : ""
                }`}
              >
                {element.title === "Dashboard" && (
                  <Dashboard
                    fill={`${
                      props.mode === "light"
                        ? element.active
                          ? "#EC2A90"
                          : "#A9A9A9"
                        : "white"
                    }`}
                  />
                )}
                {element.title === "My Wallet" && (
                  <Wallet
                    fill={`${
                      props.mode === "light"
                        ? element.active
                          ? "#EC2A90"
                          : "#A9A9A9"
                        : "white"
                    }`}
                  />
                )}
                {element.title === "Transaction" && (
                  <Transaction
                    fill={`${
                      props.mode === "light"
                        ? element.active
                          ? "#EC2A90"
                          : "#A9A9A9"
                        : "white"
                    }`}
                  />
                )}
                {element.title === "Analytics" && (
                  <Analytics
                    fill={`${
                      props.mode === "light"
                        ? element.active
                          ? "#EC2A90"
                          : "#A9A9A9"
                        : "white"
                    }`}
                  />
                )}
                {element.title === "Reports" && (
                  <Reports
                    fill={`${
                      props.mode === "light"
                        ? element.active
                          ? "#EC2A90"
                          : "#A9A9A9"
                        : "white"
                    }`}
                  />
                )}
                {element.title === "Message" && (
                  <Message
                    fill={`${
                      props.mode === "light"
                        ? element.active
                          ? "#EC2A90"
                          : "#A9A9A9"
                        : "white"
                    }`}
                  />
                )}
                {element.title === "Settings" && (
                  <Settings
                    fill={`${
                      props.mode === "light"
                        ? element.active
                          ? "#EC2A90"
                          : "#A9A9A9"
                        : "white"
                    }`}
                  />
                )}
                <span className={`ml-3 ${element.active ? "font-bold" : ""}`}>
                  {element.title}
                </span>
              </a>
            </li>
          ))}
        </ul>
      </div>
    </aside>
  );
};

export default SideNavigation;
