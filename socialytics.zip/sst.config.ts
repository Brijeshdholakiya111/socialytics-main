import { SSTConfig } from "sst";
import FrontendStack from "./stacks/frontend";

export default {
  config(_input: any) {
    return {
      name: "winncloud",
      region: "us-east-1",
    };
  },
  stacks(app: any) {
    app.stack(FrontendStack);
  },
};
