import { Fragment, useState } from "react";
import { Menu, Transition } from "@headlessui/react";
import { ChevronDownIcon, ChevronRightIcon } from "@heroicons/react/24/solid";
function classNames(...classes: string[]) {
  return classes.filter(Boolean).join(" ");
}
type DropdownType = {
  data?: object[];
  title?: string;
  handleSelected: Function;
};
export default function Dropdown(props: DropdownType) {
  const [active, setActive] = useState(false);
  const handleDropdown = () => {
    setActive(!active);
  };
  const handleSelect = (value: any) => {
    props.handleSelected(value);
  };
  return (
    <Menu as="div" className="relative inline-block text-left">
      <div>
        <Menu.Button
          onClick={handleDropdown}
          className="inline-flex w-[150px] items-center justify-center rounded-xl border border-[#D6EFFF]  py-2 px-2 text-sm font-bold text-[#3080FE] shadow-sm"
        >
          <div className="mr-2 h-[30px] w-[30px] rounded-[6px] bg-gray-200"></div>
          {props.title}
          {active ? (
            <ChevronRightIcon
              className="-mr-1 ml-2 h-4 w-4"
              aria-hidden="true"
            />
          ) : (
            <ChevronDownIcon
              className="-mr-1 ml-2 h-4 w-4"
              aria-hidden="true"
            />
          )}
        </Menu.Button>
      </div>
      <Transition
        as={Fragment}
        enter="transition ease-out duration-100"
        enterFrom="transform opacity-0 scale-95"
        enterTo="transform opacity-100 scale-100"
        leave="transition ease-in duration-75"
        leaveFrom="transform opacity-100 scale-100"
        leaveTo="transform opacity-0 scale-95"
      >
        <Menu.Items className="absolute left-0 z-[100] mt-2 w-[9.188rem] origin-top-right rounded-xl bg-[#D6EFFF] shadow-lg ring-1 ring-black ring-opacity-5">
          <div className="h-full py-1">
            {props?.data?.map((element: any, index: number) => (
              <Menu.Item key={index}>
                {({ active }) => (
                  <a
                    href="#"
                    onClick={(e) => handleSelect(element)}
                    className={classNames(
                      active ? "bg-gray-100 text-[#3080FE]" : "text-[#3080FE]",
                      "block px-4 py-2 text-sm"
                    )}
                  >
                    {element?.value}
                  </a>
                )}
              </Menu.Item>
            ))}
          </div>
        </Menu.Items>
      </Transition>
    </Menu>
  );
}
