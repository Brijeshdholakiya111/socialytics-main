import Layout from "@/components/layout";
import Button from "@/components/Button";
import Dropdown from "@/components/Dropdown";
import { useEffect, useState } from "react";
import Input from "@/components/Input";
import Avatar from "@/components/Avatar";
import Profile from "@/components/Profile";
import SideNavigation from "@/components/SideNavigation";
import TopNavigation from "../../components/TopNavigation";
import Table from "@/components/Table";
import ChartArea from "@/components/ChartArea";
import ChartArea2 from "@/components/ChartArea2";
import { BarChart } from "../../components/BarChart";
import ChartArea3 from "@/components/ChatArea3";
import Table2 from "@/components/Table2";
import Image from "next/image";
import Arrow from "../../../public/images/image 10.svg";
import TopNavigation2 from "@/components/TopNavigation2";
import FacebookIcon from "../../../public/images/facebook.svg";
import Youtube from "../../../public/images/youtube.svg";
import Spotify from "../../../public/images/spotify.svg";
import Twitch from "../../../public/images/twitch.svg";

const menu: any = [
  {
    title: "Dashboard",
    active: false,
  },
  {
    title: "My Wallet",
    active: false,
  },
  {
    title: "Transaction",
    active: false,
  },
  {
    title: "Analytics",
    active: false,
  },
  {
    title: "Reports",
    active: false,
  },
  {
    title: "Message",
    active: false,
  },
  {
    title: "Settings",
    active: false,
  },
];

export default function IndexPage() {
  const [dropdown, setDropdown] = useState([
    {
      key: 1,
      value: "Weekly",
    },
    {
      key: 2,
      value: "Monthly",
    },
    {
      key: 3,
      value: "Annually",
    },
  ]);
  const [selected, setSelected] = useState("");

  const [profile, setProfile] = useState({
    name: "Adam Levine",
    designation: "Digital Designer",
    image:
      "https://images.unsplash.com/photo-1491528323818-fdd1faba62cc?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=facearea&facepad=2&w=256&h=256&q=80",
  });

  const [navBar, setNavBar] = useState();
  const setTheme: any =
    typeof window != "undefined" && localStorage.getItem("dark-theme");
  const [darkTheme, setDarkTheme]: any = useState(JSON.parse(setTheme));

  useEffect(() => {
    setNavBar(menu);
  }, []);

  const handleSelected = (element: any) => {
    setSelected(element.value);
  };

  const handleActive = (index: number) => {
    const newArr: any = [...menu];
    newArr[index].active = true;
    setNavBar(newArr);
  };

  const getFormattedNumber = (number: number) => {
    return new Intl.NumberFormat("en-IN", {
      maximumSignificantDigits: 2,
    }).format(number);
  };

  const data = [
    {
      date: "01-20-2023",
      day: "THU",
      subscriber: 11652890,
      video_views: 1234764,
      video_views2: 1234764,
      growth: 44,
      estimated_earnings: "$0-$5.2K",
      status: "great",
    },
    {
      date: "01-27-2023",
      day: "TUE",
      subscriber: 10252890,
      video_views: 1234764,
      video_views2: 1234764,
      growth: 44,
      estimated_earnings: "$0-$5.2K",
      status: "good",
    },
    {
      date: "02-15-2023",
      day: "MON",
      subscriber: 9892233,
      video_views: 1234764,
      video_views2: 1234764,
      growth: 44,
      estimated_earnings: "$0-$5.2K",
      status: "great",
    },
    {
      date: "02-27-2023",
      day: "FRI",
      subscriber: 8622890,
      video_views: 1234764,
      video_views2: 1234764,
      growth: -24,
      estimated_earnings: "$0-$5.2K",
      status: "excellent",
    },
    {
      date: "02-15-2023",
      day: "MON",
      subscriber: 9892233,
      video_views: 1234764,
      video_views2: 1234764,
      growth: 44,
      estimated_earnings: "$0-$5.2K",
      status: "good",
    },
  ];

  const columns = [
    {
      Header: () => (
        <div
          style={{
            textAlign: "left",
          }}
        >
          Date
        </div>
      ),
      accessor: "date",
      Cell: ({ row }: any) => {
        return (
          <div className="px-4 py-6">
            {row.values.date}
            <span className="ml-2 text-sm text-gray-400">
              {row.original.day}
            </span>{" "}
          </div>
        );
      },
    },
    {
      Header: "Subscribers",
      accessor: "subscriber",
      Cell: ({ row }: any) => {
        return (
          <div className="px-4 py-4 text-center">
            {getFormattedNumber(row.values.subscriber)}
          </div>
        );
      },
    },
    {
      Header: "Video Views",
      accessor: "video_views",
      Cell: ({ row }: any) => {
        return (
          <div className="flex justify-center gap-2 px-4 py-4 text-center">
            <Image src={Arrow} alt={"arrow"} />
            <div className="text-[#03DE73]">
              {/* {getFormattedNumber(row.values.video_views2)} */}
              {row.values.video_views2}
            </div>
            {getFormattedNumber(row.values.video_views)}
          </div>
        );
      },
    },
    {
      Header: "Growth",
      accessor: "growth",
      Cell: ({ row }: any) => {
        return (
          <div
            className={`text-green px-4 py-4 text-center font-bold text-green-500 ${
              row.values.growth < 0 ? "text-red-500" : "text-green-500"
            } `}
          >
            {row.values.growth > 0 && "+"}
            {row.values.growth}%
          </div>
        );
      },
    },
    {
      Header: "Estimated Earnings",
      accessor: "estimated_earnings",
      Cell: ({ row }: any) => {
        return (
          <div className="px-4 py-4 text-center">
            {row.values.estimated_earnings}
          </div>
        );
      },
    },
    {
      Header: "Status",
      accessor: "status",
      Cell: ({ row }: any) => {
        if (row.values.status === "great") {
          return (
            <span className="mx-auto block w-28 rounded-2xl p-2 text-center text-sm font-semibold uppercase text-green-500">
              {row.values.status}
            </span>
          );
        } else if (row.values.status === "good") {
          return (
            <span className="mx-auto block w-28 rounded-2xl p-2  text-center  text-sm font-semibold uppercase text-[#F98B09]">
              {row.values.status}
            </span>
          );
        } else if (row.values.status === "bad") {
          return (
            <span className="mx-auto block w-28 rounded-2xl p-2 text-center  text-sm font-semibold uppercase text-red-500">
              {row.values.status}
            </span>
          );
        } else if (row.values.status === "excellent") {
          return (
            <span className="mx-auto block w-28 rounded-2xl p-2 text-center  text-sm font-semibold uppercase text-[#50B1F9]">
              {row.values.status}
            </span>
          );
        }
        return null;
      },
    },
  ];

  const categories = ["Mon", "Tue", "Wed", "Thus", "Fri", "Sat", "Sun"];
  const chartData = [
    {
      type: "spline",
      data: [20, 30, 30, 75, 85, 40, 80, 30, 55],
    },
  ];

  return (
    <Layout>
      <div className="p-4 sm:ml-64 sm:w-[calc(100%-240px)]">
        <main>
          <div>
            <TopNavigation2
              setDarkTheme={setDarkTheme}
              darkTheme={darkTheme}
              profileData={profile}
            />
          </div>
          <div>
            <div className="mt-12 grid grid-cols-1 gap-4 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-2">
              <div className="space-y-2">
                <h3 className="p-2 font-bold">Followers Gained Per Week</h3>
                <div className="grid w-full w-full grid-cols-1 gap-4 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-1">
                  <BarChart
                    title="Followers Gained (Weekly)"
                    categories={categories}
                    data={chartData}
                  />
                </div>
              </div>
              <div className="grid grid-cols-1 gap-4 md:grid-cols-1 lg:grid-cols-2 xl:grid-cols-2">
                <ChartArea3
                  icon={FacebookIcon}
                  notHover
                  title="Facebook Visitors"
                  value="+35.52%"
                  changeRate="+3.4%"
                />
                <ChartArea3
                  notHover
                  icon={Youtube}
                  title="Youtube Visitors"
                  value="-+6.52%"
                  changeRate="-16.1%"
                  darkTheme={darkTheme}
                />
                <ChartArea3
                  icon={Spotify}
                  notHover
                  title="Instagram Visitors"
                  value="+18.32%"
                  changeRate="0.0%"
                />
                <ChartArea3
                  icon={Twitch}
                  notHover
                  title="Twitch Visitors"
                  value="+26.32%"
                  changeRate="+3.4%"
                />
              </div>
            </div>
            <div className="mt-5 rounded-[12px] p-6 shadow-[0_0_14px_rgb(0,0,0,0.1)]">
              <h3 className="pb-7 pt-3 font-bold">Followers Gained (Weekly)</h3>
              <Table2 columns={columns} data={data} darkTheme={darkTheme} />
            </div>
          </div>
        </main>
        <div>
          <SideNavigation
            mode="light"
            menu={navBar}
            handleActive={handleActive}
          />
        </div>
      </div>
    </Layout>
  );
}
