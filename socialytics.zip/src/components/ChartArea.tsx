import Expand from "../../public/images/Expand.svg";
import Highcharts from "highcharts";
import HighchartsReact from "highcharts-react-official";
import ChartLight from "../../public/images/Chartlight.png";
import ChartDark from "../../public/images/Chartdark.png";
import Image from "next/image";

type ChartProps = {
  title?: string;
  value?: string;
  changeRate?: string;
  dark?: boolean;
  darkTheme?: string;
  down?: boolean;
};

const options = {
  chart: {
    height: 130,
    width: 100,
  },
  credits: {
    enabled: false,
  },
  legend: {
    enabled: false,
  },
  title: {
    text: "",
  },
  series: [
    {
      type: "area",
      data: [120, 280, 220, 180, 320],
    },
  ],
  yAxis: {
    visible: false,
  },
  xAxis: {
    visible: false,
  },
};

export default function ChartArea(props: ChartProps) {
  return (
    <div
      className={`overflow-hidden rounded-xl border border-b-[8px] border-gray-300 border-b-blue-500 p-6 shadow-[md] drop-shadow-2xl transition-[1s] hover:translate-y-[-16px] hover:border-b-[1px] hover:border-b-gray-300 hover:shadow-xl  ${props.dark
        ? "filter-[drop-shadow(0px 10px 10px rgba(1, 27, 56, 0.28))] border-b-transparent bg-[#011B38] text-white"
        : ""
        }`}
    >
      <div className="flex items-center justify-between gap-6 border-b pb-4">
        <p className="font-semibold">{props.title}</p>
        <button>
          <img src={Expand.src} />
        </button>
      </div>

      <div className="space-y-1">
        <div className="flex flex-wrap items-center justify-between gap-3 py-7">
          <div className="mt-4 flex items-end gap-3">
            <p
              className={`text-5xl font-extrabold ${props?.value?.length ?? 0 > 3 ? "text-[28px]" : "text-[52px]"
                }`}
            >
              {props.value}
            </p>
            <span
              className={`block w-[max-content] rounded-md px-2 py-1 text-center text-[13px] font-medium ${props.down
                ? "bg-[#F95A5A20] text-[#F95A5A]"
                : "bg-green-100 text-green-500"
                }`}
            >
              {props.changeRate}
            </span>
          </div>
          {/* <HighchartsReact highcharts={Highcharts} options={options} /> */}
          <Image
            src={props.down ? ChartDark : ChartLight}
            height={55}
            width={85}
            alt={"chart"}
          />
        </div>

        <p className="font-medium text-gray-500">
          Followers For The Last 30 Days
        </p>
      </div>
    </div>
  );
}
