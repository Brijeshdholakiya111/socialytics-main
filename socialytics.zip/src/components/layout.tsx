// import Head from 'next/head'

// type LayoutProps = {
//   children: React.ReactNode;
//   title?: String;
//   darkTheme: any;
//   setDarkTheme: any;
// };
// export default function Layout({
//   children,
//   title = "This is the default title",
//   darkTheme,
// }: LayoutProps) {
//   return (
//     <div
//       className={`transition-[1s] ${darkTheme ? "bg-[#011B38] text-white" : "bg-white text-black"
//         }`}
//     >
//       <Head>
//         <title>{title}</title>
//         <meta charSet="utf-8" />
//         <meta name="viewport" content="initial-scale=1.0, width=device-width" />
//       </Head>
//       <div className='p-5'>
//         {children}
//       </div>
//     </div>
//   )
// }

import SideNavigation from "@/components/SideNavigation";
import TopNavigation from "../components/TopNavigation";
import { useRouter } from "next/router";
import { useSession } from "next-auth/react";

interface LayoutProps {
  children?: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const router = useRouter();
  const { data: session } = useSession();
  const hideSidebar = router.pathname.includes("/login");
  // if (typeof window !== 'undefined') {
  //   if (!session) {
  //     router.push('/login')
  //   }
  // }
  console.log("ssssssss", session);

  return (
    <>
      {hideSidebar ? (
        <>
          <SideNavigation handleActive={() => { }} menu={undefined} mode={""} />
          <TopNavigation
            darkTheme={undefined}
            profileData={undefined}
            setDarkTheme={undefined}
          />
        </>
      ) : null}
      <main>{children}</main>
    </>
  );
}
