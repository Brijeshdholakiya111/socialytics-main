import Image from "next/image";
import { useEffect, useState } from "react";
import Avatar from "./Avatar";
import Input from "./Input";
import lightIcon from "../../public/images/light-icon.svg";
import darkIcon from "../../public/images/dark-icon.svg";
import Dropdown from "./Dropdown";

interface profileType {
  darkTheme: any;
  profileData: any;
  setDarkTheme: any;
}

export default function TopNavigation2(props: profileType) {
  const [isOpen, setIsOpen] = useState(true);
  const [dropdown, setDropdown] = useState([
    {
      key: 1,
      value: "Profile",
    },
    {
      key: 2,
      value: "Logout",
    },
  ]);
  const [selected, setSelected] = useState("");

  const handleOption = (isOpen: boolean) => {
    setIsOpen(!isOpen);
  };

  const handletheam = () => {
    localStorage.setItem("dark-theme", `${!props.darkTheme}`);
    props.setDarkTheme(!props.darkTheme);
  };

  const handleSelected = (element: any) => {
    setSelected(element.value);
  };

  return (
    <nav className="fixed top-0 z-[100] rounded border-gray-200 bg-white px-2 py-2.5 shadow-md sm:px-4">
      <div className="container flex flex-wrap items-center gap-x-10 gap-y-5 lg:flex-nowrap">
        <div className="flex items-center gap-x-10">
          <a href="#" className="flex items-center">
            <span className="self-center whitespace-nowrap text-[36px] font-semibold dark:text-white">
              Winn Solutions Dashboard
            </span>
          </a>
          <button
            data-collapse-toggle="navbar-default"
            type="button"
            className="ml-3 inline-flex items-center rounded-lg p-2 text-sm text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200 dark:text-gray-400 dark:hover:bg-gray-700 dark:focus:ring-gray-600 md:hidden"
            aria-controls="navbar-default"
            aria-expanded="false"
            onClick={(e) => handleOption(isOpen)}
          >
            <span className="sr-only">Open main menu</span>
            <svg
              className="h-6 w-6"
              aria-hidden="true"
              fill="currentColor"
              viewBox="0 0 20 20"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                fillRule="evenodd"
                d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 10a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zM3 15a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z"
                clipRule="evenodd"
              ></path>
            </svg>
          </button>
        </div>
        <div
          className={`${
            isOpen ? "flex" : "hidden md:flex"
          } w-full items-center justify-end`}
        >
          <div className="flex w-full justify-center gap-4 text-center align-middle text-black">
            <Input
              placeholder="Search Data or some visualization"
              variant="search"
              width="w-full"
              darkTheme={props.darkTheme}
            />

            <button
              title={`${props.darkTheme ? "Dark Theme" : "Light Theme"}`}
              className="mx-3"
              // onClick={() => props.settheam(!props.darktheam)}
              onClick={() => handletheam()}
            >
              {props.darkTheme ? (
                <Image
                  src={darkIcon}
                  className="rotate-[320deg] transform"
                  alt=""
                />
              ) : (
                <Image src={lightIcon} alt="" />
              )}
            </button>
            <div className="flex items-center rounded-[10px] border px-2">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth={1.5}
                stroke="gray"
                className="h-8 w-8  "
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M14.857 17.082a23.848 23.848 0 005.454-1.31A8.967 8.967 0 0118 9.75v-.7V9A6 6 0 006 9v.75a8.967 8.967 0 01-2.312 6.022c1.733.64 3.56 1.085 5.455 1.31m5.714 0a24.255 24.255 0 01-5.714 0m5.714 0a3 3 0 11-5.714 0"
                />
              </svg>
            </div>

            <Dropdown
              title="John Smith"
              data={dropdown}
              handleSelected={handleSelected}
            />
          </div>
        </div>
      </div>
    </nav>
  );
}
